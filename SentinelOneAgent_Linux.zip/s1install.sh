#!/bin/bash
#
# Script to install Sentinel One agent for Linux
# Change log:
#    9/13/2023 - Initial - Tim Morris

# Declare some empty vars
FILE_EXTENSION=''
PACKAGE_MANAGER=''
AGENT_INSTALL_SYNTAX=''
AGENT_FILE_NAME='SentinelAgent_linux*'

# Path to script and files
SCRIPTDIR=`pwd`

# Revert to normal colors
Color_Off='\033[0m'       # Text Resets
# Regular Colors
Red='\033[0;31m'          # Red
Green='\033[0;32m'        # Green
Yellow='\033[0;33m'       # Yellow

# Check if running as root
if [[ $(/usr/bin/id -u) -ne 0 ]]; then
    printf "\n${Red}ERROR:  This script must be run as root.  Please retry with 'sudo'.${Color_Off}\n"
    exit 1
fi

# Detect if the Linux Platform uses RPM/DEB packages and the correct Package Manager to use
if (cat /etc/*release |grep 'ID=ubuntu' || cat /etc/*release |grep 'ID=debian'); then
    FILE_EXTENSION='.deb'
    PACKAGE_MANAGER='apt'
    AGENT_INSTALL_SYNTAX='dpkg -i'
elif (cat /etc/*release |grep 'ID="rhel"' || cat /etc/*release |grep 'ID="amzn"' || cat /etc/*release |grep 'ID="centos"' || cat /etc/*release |grep 'ID="ol"' || cat /etc/*release |grep 'ID="scientific"' || cat /etc/*release |grep 'ID="rocky"' || cat /etc/*release |grep 'ID="almalinux"'); then
    FILE_EXTENSION='.rpm'
    PACKAGE_MANAGER='yum'
    AGENT_INSTALL_SYNTAX='rpm -i --nodigest'
elif (cat /etc/*release |grep 'ID="sles"'); then
    FILE_EXTENSION='.rpm'
    PACKAGE_MANAGER='zypper'
    AGENT_INSTALL_SYNTAX='rpm -i --nodigest'
elif (cat /etc/*release |grep 'ID="fedora"' || cat /etc/*release |grep 'ID=fedora'); then
    FILE_EXTENSION='.rpm'
    PACKAGE_MANAGER='dnf'
    AGENT_INSTALL_SYNTAX='rpm -i --nodigest'
else
    printf "\n${Red}ERROR:  Unknown Operating System Release ID: $1 ${Color_Off}\n"
    printf "\n${Red}        Please run on a supported system! ${Color_Off}\n"
    cat /etc/*release
    echo ""
    exit 1
fi

################ Starting install

# Remove trend agent here...
printf "\nRemoving Trend Deep Security agent (if installed) ...\n"
$PACKAGE_MANAGER remove ds_agent -y

# Install Sentinel One Agent
printf "\nInstall Sentinel One Agent ...\n"
export S1_AGENT_INSTALL_CONFIG_PATH="$SCRIPTDIR/config.cfg"
$AGENT_INSTALL_SYNTAX $SCRIPTDIR/SentinelAgent_linux*${FILE_EXTENSION}
if [ $? != 0 ]; then
    printf "\n${Red}Installation failed. Exiting!${Color_Off}\n"
    exit 1
fi

# Register to Sentinel One
printf "\nRegistering sentinel ${HOSTNAME}...\n"
/opt/sentinelone/bin/sentinelctl management token set eyJ1cmwiOiAiaHR0cHM6Ly91c2VhMS0wMTcuc2VudGluZWxvbmUubmV0IiwgInNpdGVfa2V5IjogIjQ1YWMzOWM5YWE1NTZhMjcifQ==
if [ $? != 0 ]; then
    printf "\n${Red}Unable to set management token. Exiting!${Color_Off}\n"
    exit 1
fi

# Start Sentinel One Agent
printf "\nStarting Sentinel One Agent ...\n"
/opt/sentinelone/bin/sentinelctl control start
if [ $? != 0 ]; then
    printf "\n${Red}Unable to start SentinelOne agent. Exiting!${Color_Off}\n"
    exit 1
fi

printf "\n${Green}SentinelOne agent has been installed, registered and started.${Color_Off}\n"
