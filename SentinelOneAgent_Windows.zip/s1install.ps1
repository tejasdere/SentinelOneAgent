#Requires -RunAsAdministrator
# 
#--------------------------------------------------------------------------------------
# Removes the Trend ServerProtect agent and installs SentinelOne
#--------------------------------------------------------------------------------------

# Name of the MSI installer
$installer = "SentinelInstaller_windows_64bit_v23_1_5_886.msi"

# Site TOKEN
$site_token = "eyJ1cmwiOiAiaHR0cHM6Ly91c2VhMS0wMTcuc2VudGluZWxvbmUubmV0IiwgInNpdGVfa2V5IjogIjQ1YWMzOWM5YWE1NTZhMjcifQ=="

# Allow system to be rebooted
$auto_reboot = "True"

# Make sure we are run as Administrator
function Test-Administrator  
{  
    [OutputType([bool])]
    param()
    process {
        [Security.Principal.WindowsPrincipal]$user = [Security.Principal.WindowsIdentity]::GetCurrent();
        return $user.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator);
    }
}

if(-not (Test-Administrator))
{
    # TODO: define proper exit codes for the given errors 
    Write-Error "This script must be executed as Administrator.";
    exit 1;
}

# Confirm a REBOOT is OK
Write-Warning "This script WILL REBOOT your system!!"
$confirm = Read-Host "Are you sure? (Y/N)"
if ($confirm -ieq 'Y') {
	Write-Host "Proceeding..."
} else {
	Write-Error "Script canceled!"
	exit 1
}

# Get current directory
$current_dir = (Get-Item .).FullName

# Check if MSI file exists
if (!(Test-Path $installer) -and !(Test-Path $installer)) {
	Write-Warning "$installer not found! Exiting!"
	Exit 1
}

# Uninstall Trend Micro Deep Security Agent
Write-host "Uninstalling Trend Micro Deep Security Agent"
$Trend = Get-WmiObject -Class Win32_Product | Where-Object{$_.Name -eq 'Trend Micro Deep Security Agent'}
& "msiexec.exe" /x $Trend.IdentifyingNumber /quiet /norestart /log $env:TEMP\trend_uninstall.log
if ( $? -ne $true ) {
	Write-Warning "Trend Micro Deep Security Agent encountered an error while uninstalling!" 
	Write-Warning "Please uninstall manually and try again. Exiting."
	exit 1
}


# Disable Windows Defender
try { 
	$service = Get-Service -Name windefend -ErrorAction Stop
	switch ($service.Status) {
		'Stopped' { 
			if ($service.StartType -eq "Disabled" -Or $service.StartType -eq "Manual") {
				Write-Host "Defender service is already disabled. Skipping."
			} else {
				Write-Warning "Unable to determine Defender status!"
				Write-Warning "Please verify there are no other AV agents installed and try again. Exiting."
				exit 1
			}
		}
		'Running' {
			Write-Host "Disabling Defender."
			Set-MpPreference -DisableRealtimeMonitoring $true
		}
	}
}
catch { "Defender service not found. Skipping." }

# Install SentinelOne Agent
Write-host "Installing SentinelOne Agent"
# Execute using newer cli flags
if($auto_reboot -eq "True") {
	# Execute the package with the quiet option and force restart
	& "msiexec.exe" /i $installer SITE_TOKEN=$site_token /qn /forcerestart /log $env:TEMP\sentinel_msi.log
	Write-host "Installation initiated. Installation may take up to 15 minutes to complete. Please be patient."
    Write-Warning "The system will reboot once finished."
}
else {
	# Execute the package with the quiet option and do NOT restart
    & "msiexec.exe" /i $installer SITE_TOKEN=$site_token /qn /norestart /log $env:TEMP\sentinel_msi.log
	Write-host "Installation initiated. Installation may take up to 15 minutes to complete. You will see a notification once finished."
	Write-Warning "The system will require a reboot once finished."
}
